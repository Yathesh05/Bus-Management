package com.projectbus.demo;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class BusService {
	@Autowired
	private BusRepository busRepository;
	Bus s=new Bus();
	public void addServiceBus(Bus s)
	{
		busRepository.save(s);
	}
	public void  deletebus(long id)
	{
		busRepository.deleteById(id);
	}
	public Optional findbyid(long id)
	{
		return busRepository.findById(id);
		
	}
	public void updatebus(long id)
	{
     	s=busRepository.findById(id).get();
//		s.setEmp_name("vishnu");
		busRepository.save(s);
	}


}
