package com.projectbus.demo;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "bus_details")
public class Bus {
	
	@Id
	private long bus_id;
	private String bus_src_loc;
	private String bus_dest_loc;
	private double bus_fare;
	private String bus_timing;
	 
	public Long getbus_id() {
		return bus_id;
	}
	public void setbus_id(Long bus_id) {
		this.bus_id = bus_id;
	}
	public String getbus_src_loc() {
		return bus_src_loc;
	}
	public void bus_src_loc(String bus_src_loc) {
		this.bus_src_loc = bus_src_loc;
	}
	public double getbus_fare() {
		return bus_fare;
	}
	public void setbus_fare(double bus_fare) {
		this.bus_fare = bus_fare;
	}
	public String getbus_timiing() {
		return bus_timing;
	}
	public void setbus_timiing(String bus_timiing) {
		this.bus_timing = bus_timiing;
	}
	

}
