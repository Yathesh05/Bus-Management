package com.projectbus.demo;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.projectbus.demo.Bus;
import com.projectbus.demo.BusService;

@RestController
@RequestMapping("/Bus")
public class BusController {
	@Autowired
	private BusService busService;
	
	@PostMapping("/addbus")
	public String addBus(@RequestBody Bus s) {
		busService.addServiceBus(s);
		return "Bus Added Successfully";
	}
	@DeleteMapping("/deletebus/{id}")
	public String deletebus (@PathVariable long id )
	{
		busService.deletebus(id);
		return "Bus deleted successfully";
		
	}
	@GetMapping("/getbus/{id}")
	public Optional findbyid(@PathVariable long id)
	{
		return busService.findbyid(id);
	}
	@PutMapping("/updatebus/{id}")
	public void updatebus(@PathVariable long id)
	{
		busService.updatebus(id);
	}


}
